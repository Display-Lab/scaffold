import re
import sys
from typing import List

import pandas as pd
from loguru import logger
from rdflib import DCTERMS, RDF, BNode, Graph, URIRef
from rdflib.resource import Resource

from scaffold import context
from scaffold.utils import SLOWMO
from scaffold.utils.namespace._PSDO import PSDO
from scaffold.utils.settings import settings

candidate_df: pd.DataFrame = pd.DataFrame()
response_df: pd.DataFrame = pd.DataFrame()


def analyse_responses():
    global response_df

    r2 = (
        response_df.groupby("causal_pathway")["subject"]
        .agg(count=("count"))
        .reset_index()
    )

    r2["%  "] = round(r2["count"] / r2["count"].sum() * 100, 1)

    print(f"\n {r2} \n")


def analyse_candidates(OUTPUT):
    global candidate_df

    if OUTPUT:
        candidate_df.to_csv(OUTPUT, index=False)

    candidate_df.rename(columns={"acceptable_by": "causal_pathway"}, inplace=True)
    candidate_df["score"] = candidate_df["score"].astype(float)
    candidate_df.rename(columns={"name": "message"}, inplace=True)

    # causal pathways
    causal_pathway_report = build_table("causal_pathway")
    print(causal_pathway_report, "\n")

    # messages
    message_report = build_table("message")
    print(message_report, "\n")

    # measures
    measure_report = build_table("measure")
    print(measure_report, "\n")


def build_table(grouping_column):
    candidate_df["selected1"] = (
        pd.to_numeric(candidate_df["selected"], errors="coerce")
        .fillna(0)
        .astype(int)
    )
    
    report_table = (
        candidate_df.groupby(grouping_column)["selected1"]
        .agg(acceptable=("count"), selected=("sum"))
        .reset_index()
    )
    scores = round(
        candidate_df.groupby(grouping_column)["score"]
        .agg(acceptable_score=("mean"))
        .reset_index(),
        2,
    )
    report_table = pd.merge(report_table, scores, on=grouping_column, how="left")

    report_table["% acceptable"] = round(
        report_table["acceptable"] / report_table["acceptable"].sum() * 100, 1
    )
    report_table["% selected"] = round(
        report_table["selected"] / report_table["selected"].sum() * 100, 1
    )
    report_table["% of acceptable selected"] = round(
        report_table["selected"] / report_table["acceptable"] * 100, 1
    )
    selected_scores = round(
        candidate_df[candidate_df["selected"]]
        .groupby(grouping_column)["score"]
        .agg(selected_score=("mean"))
        .reset_index(),
        2,
    )
    report_table = pd.merge(
        report_table, selected_scores, on=grouping_column, how="left"
    )

    report_table = report_table[
        [
            grouping_column,
            "acceptable",
            "% acceptable",
            "acceptable_score",
            "selected",
            "% selected",
            "selected_score",
            "% of acceptable selected",
        ]
    ]

    return report_table


def add_candidates(response_data: dict):
    global candidate_df
    data = response_data.get("candidates", None)
    if data:
        candidates = pd.DataFrame(data[1:], columns=data[0])
        candidates["performance_month"] = context.performance_month
        candidate_df = pd.concat([candidate_df, candidates], ignore_index=True)


def add_response(response_data):
    global response_df
    selected_candidate = response_data.get("selected_candidate", None)

    response_dict: dict = {
        "subject": [response_data.get("subject", None)],
        "causal_pathway": selected_candidate["acceptable_by"]
        if selected_candidate
        else [None],
    }
    response_df = pd.concat(
        [response_df, pd.DataFrame(response_dict)], ignore_index=True
    )
    print(response_dict, end="\r")


def extract_number(filename):
    # Extract numeric part from filename
    match = re.search(r"_(\d+)", str(filename))
    if match:
        return int(match.group(1))
    else:
        return float("inf")  # Return infinity if no numeric part found


def set_logger():
    logger.remove()
    logger.add(
        sys.stdout,
        colorize=True,
        format="{level}|  {message}",
        level=settings.log_level,
    )
    logger.at_least = (
        lambda lvl: logger.level(lvl).no >= logger.level(settings.log_level).no
    )


def merge_and_pivot(performance_df):
    # prepare performance data
    performance_enriched = performance_df.merge(
        context.practitioner_role,
        how="left",
        left_on="subject",
        right_on="PractitionerRole.identifier",
    )

    pivoted_comparator = context.comparator_df.pivot_table(
        index=["period.start", "measure", "group.subject", "PractitionerRole.code"],
        columns="group.code",
        values="measureScore.rate",
    ).reset_index()

    final_df = performance_enriched.merge(
        pivoted_comparator,
        how="left",
        left_on=["period.start", "measure"],
        right_on=["period.start", "measure"],
    )

    performance_df = final_df.copy()

    return performance_df

def candidates(
    performer_graph: Graph, measure: BNode = None, filter_acceptable: bool = False
) -> List[Resource]:
    """
    Retrieve a list of candidate resources from the performer graph.

    Parameters:
        performer_graph (Graph): The performer_graph.
        measure (BNode, optional): The measure to filter candidates. Defaults to None.
        filter_acceptable (bool, optional): Whether to filter candidates based on acceptability. Defaults to False.

    Returns:
        List[Resource]: A list of candidate BNodes.
    """

    candidates = [
        performer_graph.resource(subject)
        for subject in performer_graph.subjects(RDF.type, SLOWMO.Candidate)
    ]

    candidates = [
        candidate
        for candidate in candidates
        if (
            (
                measure is None
                or candidate.value(SLOWMO.RegardingMeasure).identifier == measure
            )
            and (
                not filter_acceptable
                or candidate.value(SLOWMO.AcceptableBy) is not None
            )
        )
    ]

    return candidates


def render(performer_graph: Graph, candidate: BNode) -> dict:
    """
    creates selected message from a selected candidate.

    Parameters:
    - performer_graph (Graph): The performer_graph.
    - candidate (BNode): The candidate.

    Returns:
    BNode: selected message.
    """
    s_m = {}

    # print(self.node)
    if candidate is None:
        s_m["message_text"] = "No message selected"
        return s_m
    else:
        temp_name = SLOWMO.name  # URI of template name?
        o2wea = []
        candidate_resource = performer_graph.resource(candidate)

        ## Format selected_candidate to return for pictoralist-ing
        for s21, p21, o21 in performer_graph.triples(
            (candidate, SLOWMO.AncestorTemplate, None)
        ):
            s_m["template_id"] = o21
        # Duplicate logic above and use to pull template name
        for s21, p21, o21 in performer_graph.triples((candidate, temp_name, None)):
            s_m["template_name"] = o21

        for s2, p2, o2 in performer_graph.triples(
            (candidate, URIRef("psdo:PerformanceSummaryTextualEntity"), None)
        ):
            s_m["message_text"] = o2
        # for s212,p212,o212 in self.spek_tp.triples((s,p232,None)):

        s_m["display"] = candidate_resource.value(
            SLOWMO.Display
        ).value  # random.choice(Display)

        # for s9,p9,o9 in self.spek_tp.triples((s,p8,None)):
        #     s_m["Comparator Type"] = o9
        for s2we, p2we, o2we in performer_graph.triples(
            (candidate, SLOWMO.AcceptableBy, None)
        ):
            o2wea.append(o2we)
        # print(*o2wea)
        s_m["acceptable_by"] = o2wea

        measure = candidate_resource.value(SLOWMO.RegardingMeasure)
        s_m["measure_name"] = str(measure.identifier)
        s_m["measure_title"] = measure.value(DCTERMS.title).value
        s_m["comparator_type"] = candidate_resource.value(
            SLOWMO.RegardingComparator / SLOWMO.DisplayName
        )
        return s_m


def candidates_records(performer_graph: Graph) -> List[List]:
    """
    provides the representation of candidates as a dictionary.

    Parameters:
    - performer_graph (Graph): The performer_graph.

    Returns:
    dict: The representation of candidates as a dictionary.
    """
    candidate_list = [
        [
            "subject",
            "measure",
            "score",
            "motivating_score",
            "history_score",
            "preference_score",
            "coachiness_score",
            "name",
            "acceptable_by",
            "selected",
            "PerformanceGapSize",
            "PerformanceTrendSlope",
            "StreakLength",
            "denominator"
        ]
    ]

    for a_candidate in candidates(performer_graph, filter_acceptable=True):
        # representation = candidate_as_dictionary(a_candidate)
        representation = candidate_as_record(a_candidate)

        candidate_list.append(representation)
    return candidate_list


def candidate_as_record(a_candidate: Resource) -> List:
    representation = []

    representation.append(context.subject)
    representation.append(a_candidate.value(SLOWMO.RegardingMeasure).identifier)
    score = a_candidate.value(SLOWMO.Score)
    representation.append(score)
    representation.append(a_candidate.value(URIRef("motivating_score")))
    representation.append(a_candidate.value(URIRef("history_score")))

    representation.append(a_candidate.value(URIRef("preference_score")))
    representation.append(a_candidate.value(URIRef("coachiness_score")))

    representation.append(a_candidate.value(SLOWMO.name))
    representation.append(a_candidate.value(SLOWMO.AcceptableBy))
    representation.append(bool(a_candidate.value(SLOWMO.Selected)))
    PerformanceGapSize = ""
    PerformanceTrendSlope = ""
    StreakLength = ""
    for signal in a_candidate[PSDO.motivating_information]: 
        try:
            PerformanceGapSize = str(round(signal.value(SLOWMO.PerformanceGapSize).value,4))
        except Exception:
            pass
    
    for signal in a_candidate[PSDO.motivating_information]: 
        try:
            PerformanceTrendSlope = str(round(signal.value(SLOWMO.PerformanceTrendSlope).value,4))
        except Exception:
            pass
    
    for signal in a_candidate[PSDO.motivating_information]: 
        try:
            StreakLength = str(round(signal.value(SLOWMO.StreakLength).value,4))
        except Exception:
            pass
        
    representation.append(PerformanceGapSize)
    representation.append(PerformanceTrendSlope)
    representation.append(StreakLength)
    
    filtered = context.performance_df[
        (context.performance_df["measure"] == str(a_candidate.value(SLOWMO.RegardingMeasure).identifier)) &
        (context.performance_df["period.start"] == context.performance_month)
    ]

    if len(filtered) != 1:
        raise ValueError(f"Expected exactly 1 row, found {len(filtered)}")

    denominator = filtered.iloc[0]["measureScore.denominator"]
    representation.append(int(denominator))    

    return representation
