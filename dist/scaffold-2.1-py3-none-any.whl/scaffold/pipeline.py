import os

import psutil
from fastapi import HTTPException
from loguru import logger
from rdflib import BNode, Graph, Literal

from scaffold import context
from scaffold.bitstomach import bitstomach
from scaffold.candidate_pudding import candidate_pudding
from scaffold.context import get_preferences
from scaffold.pictoralist.pictoralist import Pictoralist
from scaffold.utils.namespace import PSDO, SLOWMO
from scaffold.utils.settings import settings
from scaffold.utils.utils import merge_and_pivot, set_logger, render, candidates_records
from random_candidate_selector import RandomCandidateSelector
from esteemer.esteemer import select_candidate


set_logger()


def pipeline():
    performance_df = bitstomach.prepare()

    # BitStomach
    logger.debug("Calling BitStomach from main...")
    g: Graph = bitstomach.extract_signals(performance_df)

    performance_content = g.resource(BNode("performance_content"))
    if len(list(performance_content[PSDO.motivating_information])) == 0:
        raise_error("Insufficient significant data found for providing feedback, process aborted. Detail: No motivating information found in the performance content.")

    context.subject_graph += g

    # candidate_pudding
    logger.debug("Calling candidate_pudding from main...")
    candidate_pudding.create_candidates()
    
    if not set(context.subject_graph[: SLOWMO.AcceptableBy :]):
        raise_error("Insufficient significant data found for providing feedback, process aborted. Detail: No acceptable candidates found after candidate creation.")
       
    # esteemer
    logger.debug("Calling Esteemer from main...")
    selected_candidate = select_candidate(context.subject_graph)
    # selected_candidate = esteemer.select_candidate(context.subject_graph)
    # selected_candidate = RandomCandidateSelector.select_candidate(context.subject_graph)

    preferences = get_preferences()
 
    if preferences["Display_Format"] and selected_candidate:
        selected_candidate[SLOWMO.Display] = Literal(
            preferences["Display_Format"]
        )

    selected_message = render(context.subject_graph, selected_candidate.identifier if selected_candidate else None)

    ### Pictoralist 2, now on the Nintendo DS: ###
    logger.debug("Calling Pictoralist from main...")
    if selected_message["message_text"] != "No message selected":
        ## Initialize and run message and display generation:
        pc = Pictoralist(
            merge_and_pivot(performance_df),
            selected_message,
            settings,
        )
        pc.prep_data_for_graphing()  # Setup dataframe of one measure, cleaned for graphing
        pc.fill_missing_months()  # Fill holes in dataframe where they exist
        pc.set_timeframe()  # Ensure no less than three months being graphed
        pc.finalize_text()  # Finalize text message and labels
        pc.graph_controller()  # Select and run graphing based on display type

        full_selected_message = pc.prepare_selected_message()
    else:
        full_selected_message = selected_message

    response = {}
    # if settings.log_level == "INFO":
    if logger.at_least("INFO"):
        # Get memory usage information
        mem_info = psutil.Process(os.getpid()).memory_info()

        response["memory (RSS in MB)"] = {
            "memory_info.rss": mem_info.rss / 1024 / 1024,
        }

        response["candidates"] = candidates_records(context.subject_graph)

    response.update(full_selected_message)

    return response

def raise_error(message):
    context.subject_graph.close()
    detail = {
            "message": message,
            "subject": context.subject,
        }
    raise HTTPException(
            status_code=400,
            detail=detail,
            headers={"400-Error": "Invalid Input Error"},
        )
